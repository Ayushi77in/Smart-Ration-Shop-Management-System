package com.RationShop.ui;

import javafx.geometry.Insets;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class MainController {

    private BorderPane view;

    public MainController() {
        view = new BorderPane();

        // TOP — header bar
        VBox header = new VBox();
        header.setPadding(new Insets(15));
        header.setStyle("-fx-background-color: #2c3e50;");

        Label title = new Label("Ration Shop Management System");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        title.setStyle("-fx-text-fill: white;");

        Label subtitle = new Label("Offline-First | Government Distribution Tracker");
        subtitle.setStyle("-fx-text-fill: #bdc3c7; -fx-font-size: 12px;");

        header.getChildren().addAll(title, subtitle);

        // CENTER — tab pane with 3 tabs
        TabPane tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        Tab beneficiaryTab = new Tab("👥 Beneficiaries");
        beneficiaryTab.setContent(new BeneficiaryController().getView());

        Tab stockTab = new Tab("📦 Stock");
        stockTab.setContent(new StockController().getView());

        Tab distributionTab = new Tab("📋 Distribution");
        distributionTab.setContent(new DistributionController().getView());

        tabPane.getTabs().addAll(beneficiaryTab, stockTab, distributionTab);

        view.setTop(header);
        view.setCenter(tabPane);
    }

    public BorderPane getView() {
        return view;
    }
}