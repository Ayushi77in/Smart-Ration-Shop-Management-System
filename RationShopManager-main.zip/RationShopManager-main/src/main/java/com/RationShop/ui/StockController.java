package com.RationShop.ui;

import com.RationShop.dao.StockDAO;
import com.RationShop.model.StockItem;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

import java.time.LocalDate;

public class StockController {

    private VBox view;
    private StockDAO dao = new StockDAO();
    private TableView<StockItem> table;
    private ObservableList<StockItem> data;

    public StockController() {
        view = new VBox(10);
        view.setPadding(new Insets(15));

        // --- HEADER ---
        Label formTitle = new Label("Stock Management");
        formTitle.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

        // --- ADD STOCK FORM ---
        TextField itemNameField = new TextField();
        itemNameField.setPromptText("Item Name (e.g. Rice)");

        TextField quantityField = new TextField();
        quantityField.setPromptText("Quantity (kg)");

        Button addButton = new Button("➕ Add Stock Item");
        addButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white; -fx-font-weight: bold;");

        // --- UPDATE STOCK FORM ---
        TextField updateNameField = new TextField();
        updateNameField.setPromptText("Item Name to Update");

        TextField updateQtyField = new TextField();
        updateQtyField.setPromptText("New Quantity (kg)");

        Button updateButton = new Button("🔄 Update Stock");
        updateButton.setStyle("-fx-background-color: #e67e22; -fx-text-fill: white; -fx-font-weight: bold;");

        Label statusLabel = new Label("");

        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(8);
        form.addRow(0, new Label("Add New:"), itemNameField, quantityField, addButton);
        form.addRow(1, new Label("Update:"), updateNameField, updateQtyField, updateButton);
        form.addRow(2, new Label(""), statusLabel);

        // --- TABLE ---
        table = new TableView<>();
        data = FXCollections.observableArrayList();

        TableColumn<StockItem, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        idCol.setPrefWidth(50);

        TableColumn<StockItem, String> nameCol = new TableColumn<>("Item Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("itemName"));
        nameCol.setPrefWidth(200);

        TableColumn<StockItem, Double> qtyCol = new TableColumn<>("Quantity (kg)");
        qtyCol.setCellValueFactory(new PropertyValueFactory<>("quantityKg"));
        qtyCol.setPrefWidth(150);

        TableColumn<StockItem, String> updatedCol = new TableColumn<>("Last Updated");
        updatedCol.setCellValueFactory(new PropertyValueFactory<>("lastUpdated"));
        updatedCol.setPrefWidth(150);

        table.getColumns().addAll(idCol, nameCol, qtyCol, updatedCol);
        table.setItems(data);
        table.setPrefHeight(350);

        refreshTable();

        // --- ADD BUTTON ACTION ---
        addButton.setOnAction(e -> {
            String name = itemNameField.getText().trim();
            String qty  = quantityField.getText().trim();

            if (name.isEmpty() || qty.isEmpty()) {
                statusLabel.setText("❌ Both fields required");
                statusLabel.setStyle("-fx-text-fill: red;");
                return;
            }

            try {
                double quantity = Double.parseDouble(qty);
                StockItem item = new StockItem(0, name, quantity, LocalDate.now().toString());
                boolean success = dao.addStockItem(item);

                if (success) {
                    statusLabel.setText("✅ Stock item added");
                    statusLabel.setStyle("-fx-text-fill: green;");
                    itemNameField.clear();
                    quantityField.clear();
                    refreshTable();
                } else {
                    statusLabel.setText("❌ Error adding item");
                    statusLabel.setStyle("-fx-text-fill: red;");
                }

            } catch (NumberFormatException ex) {
                statusLabel.setText("❌ Quantity must be a number");
                statusLabel.setStyle("-fx-text-fill: red;");
            }
        });

        // --- UPDATE BUTTON ACTION ---
        updateButton.setOnAction(e -> {
            String name = updateNameField.getText().trim();
            String qty  = updateQtyField.getText().trim();

            if (name.isEmpty() || qty.isEmpty()) {
                statusLabel.setText("❌ Both fields required");
                statusLabel.setStyle("-fx-text-fill: red;");
                return;
            }

            try {
                double quantity = Double.parseDouble(qty);
                boolean success = dao.updateStock(name, quantity);

                if (success) {
                    statusLabel.setText("✅ Stock updated");
                    statusLabel.setStyle("-fx-text-fill: green;");
                    updateNameField.clear();
                    updateQtyField.clear();
                    refreshTable();
                } else {
                    statusLabel.setText("❌ Error updating stock");
                    statusLabel.setStyle("-fx-text-fill: red;");
                }

            } catch (NumberFormatException ex) {
                statusLabel.setText("❌ Quantity must be a number");
                statusLabel.setStyle("-fx-text-fill: red;");
            }
        });

        view.getChildren().addAll(formTitle, form, new Separator(), table);
    }

    private void refreshTable() {
        data.clear();
        data.addAll(dao.getAllStock());
    }

    public VBox getView() { return view; }
}