package com.RationShop.ui;

import com.RationShop.dao.BeneficiaryDAO;
import com.RationShop.model.Beneficiary;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

public class BeneficiaryController {

    private VBox view;
    private BeneficiaryDAO dao = new BeneficiaryDAO();
    private TableView<Beneficiary> table;
    private ObservableList<Beneficiary> data;

    public BeneficiaryController() {
        view = new VBox(10);
        view.setPadding(new Insets(15));

        // --- FORM SECTION ---
        Label formTitle = new Label("Add New Beneficiary");
        formTitle.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

        TextField nameField       = new TextField();
        nameField.setPromptText("Full Name");

        TextField cardField       = new TextField();
        cardField.setPromptText("Ration Card Number");

        TextField addressField    = new TextField();
        addressField.setPromptText("Address");

        TextField phoneField      = new TextField();
        phoneField.setPromptText("Phone Number");

        TextField familyField     = new TextField();
        familyField.setPromptText("Family Size");

        Button addButton = new Button("➕ Add Beneficiary");
        addButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-weight: bold;");

        Label statusLabel = new Label("");

        // Grid layout for form
        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(8);
        form.addRow(0, new Label("Name:"), nameField, new Label("Card No:"), cardField);
        form.addRow(1, new Label("Address:"), addressField, new Label("Phone:"), phoneField);
        form.addRow(2, new Label("Family Size:"), familyField, addButton, statusLabel);

        // --- TABLE SECTION ---
        table = new TableView<>();
        data = FXCollections.observableArrayList();

        TableColumn<Beneficiary, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        idCol.setPrefWidth(50);

        TableColumn<Beneficiary, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        nameCol.setPrefWidth(150);

        TableColumn<Beneficiary, String> cardCol = new TableColumn<>("Ration Card No");
        cardCol.setCellValueFactory(new PropertyValueFactory<>("rationCardNumber"));
        cardCol.setPrefWidth(150);

        TableColumn<Beneficiary, String> addressCol = new TableColumn<>("Address");
        addressCol.setCellValueFactory(new PropertyValueFactory<>("address"));
        addressCol.setPrefWidth(150);

        TableColumn<Beneficiary, String> phoneCol = new TableColumn<>("Phone");
        phoneCol.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        phoneCol.setPrefWidth(120);

        TableColumn<Beneficiary, Integer> familyCol = new TableColumn<>("Family Size");
        familyCol.setCellValueFactory(new PropertyValueFactory<>("familySize"));
        familyCol.setPrefWidth(90);

        table.getColumns().addAll(idCol, nameCol, cardCol, addressCol, phoneCol, familyCol);
        table.setItems(data);
        table.setPrefHeight(350);

        // Load existing data
        refreshTable();

        // --- BUTTON ACTION ---
        addButton.setOnAction(e -> {
            String name    = nameField.getText().trim();
            String card    = cardField.getText().trim();
            String address = addressField.getText().trim();
            String phone   = phoneField.getText().trim();
            String family  = familyField.getText().trim();

            if (name.isEmpty() || card.isEmpty()) {
                statusLabel.setText("❌ Name and Card No required");
                statusLabel.setStyle("-fx-text-fill: red;");
                return;
            }

            int familySize = 1;
            try {
                familySize = Integer.parseInt(family);
            } catch (NumberFormatException ex) {
                statusLabel.setText("❌ Family size must be a number");
                statusLabel.setStyle("-fx-text-fill: red;");
                return;
            }

            Beneficiary b = new Beneficiary(0, name, card, address, phone, familySize);
            boolean success = dao.addBeneficiary(b);

            if (success) {
                statusLabel.setText("✅ Added successfully");
                statusLabel.setStyle("-fx-text-fill: green;");
                nameField.clear(); cardField.clear();
                addressField.clear(); phoneField.clear(); familyField.clear();
                refreshTable();
            } else {
                statusLabel.setText("❌ Error — card number may already exist");
                statusLabel.setStyle("-fx-text-fill: red;");
            }
        });

        view.getChildren().addAll(formTitle, form, new Separator(), table);
    }

    private void refreshTable() {
        data.clear();
        data.addAll(dao.getAllBeneficiaries());
    }

    public VBox getView() {
        return view;
    }
}