package com.RationShop.ui;

import com.RationShop.dao.BeneficiaryDAO;
import com.RationShop.dao.DistributionDAO;
import com.RationShop.model.Beneficiary;
import com.RationShop.model.Distribution;
import com.RationShop.service.DistributionService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

public class DistributionController {

    private VBox view;
    private BeneficiaryDAO beneficiaryDAO = new BeneficiaryDAO();
    private DistributionDAO distributionDAO = new DistributionDAO();
    private DistributionService distributionService = new DistributionService();

    public DistributionController() {
        view = new VBox(10);
        view.setPadding(new Insets(15));

        // --- HEADER ---
        Label formTitle = new Label("Monthly Ration Distribution");
        formTitle.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

        Label monthLabel = new Label("Current Month: " + distributionService.getCurrentMonth());
        monthLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #555;");

        Label quotaInfo = new Label("Standard Quota per Family → Rice: 5kg | Wheat: 3kg | Sugar: 1kg");
        quotaInfo.setStyle("-fx-font-size: 11px; -fx-text-fill: #888;");

        // --- SEARCH + DISTRIBUTE ---
        TextField searchField = new TextField();
        searchField.setPromptText("Enter Ration Card Number");
        searchField.setPrefWidth(200);

        Button searchButton = new Button("🔍 Search");
        searchButton.setStyle("-fx-background-color: #8e44ad; -fx-text-fill: white; -fx-font-weight: bold;");

        Label beneficiaryInfo = new Label("");
        beneficiaryInfo.setStyle("-fx-font-size: 12px;");

        Button distributeButton = new Button("✅ Mark as Distributed");
        distributeButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-weight: bold;");
        distributeButton.setDisable(true); // disabled until a beneficiary is searched

        Label statusLabel = new Label("");

        // Store found beneficiary temporarily
        final Beneficiary[] foundBeneficiary = {null};

        HBox searchBar = new HBox(10, new Label("Ration Card:"), searchField, searchButton);
        searchBar.setPadding(new Insets(5, 0, 5, 0));

        // --- DISTRIBUTION HISTORY TABLE ---
        Label historyTitle = new Label("Distribution History — " + distributionService.getCurrentMonth());
        historyTitle.setStyle("-fx-font-weight: bold;");

        TableView<Distribution> table = new TableView<>();
        ObservableList<Distribution> data = FXCollections.observableArrayList();

        TableColumn<Distribution, String> nameCol = new TableColumn<>("Beneficiary");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("beneficiaryName"));
        nameCol.setPrefWidth(180);

        TableColumn<Distribution, String> dateCol = new TableColumn<>("Date");
        dateCol.setCellValueFactory(new PropertyValueFactory<>("distributionDate"));
        dateCol.setPrefWidth(120);

        TableColumn<Distribution, String> monthCol = new TableColumn<>("Month");
        monthCol.setCellValueFactory(new PropertyValueFactory<>("monthYear"));
        monthCol.setPrefWidth(100);

        TableColumn<Distribution, String> itemsCol = new TableColumn<>("Items Given");
        itemsCol.setCellValueFactory(new PropertyValueFactory<>("itemsGiven"));
        itemsCol.setPrefWidth(280);

        table.getColumns().addAll(nameCol, dateCol, monthCol, itemsCol);
        table.setItems(data);
        table.setPrefHeight(300);

        // Load history for current month
        refreshHistory(data);

        // --- SEARCH BUTTON ACTION ---
        searchButton.setOnAction(e -> {
            String cardNo = searchField.getText().trim();
            if (cardNo.isEmpty()) {
                beneficiaryInfo.setText("❌ Enter a ration card number");
                beneficiaryInfo.setStyle("-fx-text-fill: red;");
                distributeButton.setDisable(true);
                return;
            }

            Beneficiary b = beneficiaryDAO.findByRationCard(cardNo);
            if (b == null) {
                beneficiaryInfo.setText("❌ No beneficiary found with this card number");
                beneficiaryInfo.setStyle("-fx-text-fill: red;");
                distributeButton.setDisable(true);
                foundBeneficiary[0] = null;
            } else {
                foundBeneficiary[0] = b;
                beneficiaryInfo.setText("✅ Found: " + b.getName() +
                        " | Family: " + b.getFamilySize() +
                        " | Address: " + b.getAddress());
                beneficiaryInfo.setStyle("-fx-text-fill: green;");
                distributeButton.setDisable(false);
                statusLabel.setText("");
            }
        });

        // --- DISTRIBUTE BUTTON ACTION ---
        distributeButton.setOnAction(e -> {
            Beneficiary b = foundBeneficiary[0];
            if (b == null) return;

            String result = distributionService.distributeRation(b.getId(), b.getName());

            switch (result) {
                case "SUCCESS":
                    statusLabel.setText("✅ Ration distributed to " + b.getName());
                    statusLabel.setStyle("-fx-text-fill: green;");
                    distributeButton.setDisable(true);
                    searchField.clear();
                    beneficiaryInfo.setText("");
                    foundBeneficiary[0] = null;
                    refreshHistory(data);
                    break;

                case "ALREADY_RECEIVED":
                    statusLabel.setText("⚠️ " + b.getName() + " already received ration this month");
                    statusLabel.setStyle("-fx-text-fill: orange;");
                    break;

                default:
                    statusLabel.setText("❌ Something went wrong");
                    statusLabel.setStyle("-fx-text-fill: red;");
            }
        });

        view.getChildren().addAll(
                formTitle, monthLabel, quotaInfo,
                new Separator(),
                searchBar, beneficiaryInfo, distributeButton, statusLabel,
                new Separator(),
                historyTitle, table
        );
    }

    private void refreshHistory(ObservableList<Distribution> data) {
        data.clear();
        String currentMonth = new DistributionService().getCurrentMonth();
        data.addAll(distributionDAO.getDistributionsByMonth(currentMonth));
    }

    public VBox getView() { return view; }
}