package com.RationShop.dao;

import com.RationShop.model.Distribution;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DistributionDAO {

    // RECORD a distribution
    public boolean addDistribution(Distribution d) {
        String sql = "INSERT INTO distributions (beneficiary_id, distribution_date, month_year, items_given) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, d.getBeneficiaryId());
            stmt.setString(2, d.getDistributionDate());
            stmt.setString(3, d.getMonthYear());
            stmt.setString(4, d.getItemsGiven());

            stmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Error recording distribution: " + e.getMessage());
            return false;
        }
    }

    // CHECK if beneficiary already received ration this month
    public boolean hasReceivedThisMonth(int beneficiaryId, String monthYear) {
        String sql = "SELECT COUNT(*) FROM distributions WHERE beneficiary_id = ? AND month_year = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, beneficiaryId);
            stmt.setString(2, monthYear);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;  // true if already received
            }

        } catch (SQLException e) {
            System.out.println("Error checking distribution: " + e.getMessage());
        }

        return false;
    }

    // GET all distributions for a specific month
    public List<Distribution> getDistributionsByMonth(String monthYear) {
        List<Distribution> list = new ArrayList<>();
        String sql = """
                SELECT d.*, b.name as beneficiary_name 
                FROM distributions d
                JOIN beneficiaries b ON d.beneficiary_id = b.id
                WHERE d.month_year = ?
                """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, monthYear);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Distribution dist = new Distribution(
                        rs.getInt("id"),
                        rs.getInt("beneficiary_id"),
                        rs.getString("beneficiary_name"),
                        rs.getString("distribution_date"),
                        rs.getString("month_year"),
                        rs.getString("items_given")
                );
                list.add(dist);
            }

        } catch (SQLException e) {
            System.out.println("Error fetching distributions: " + e.getMessage());
        }

        return list;
    }
}