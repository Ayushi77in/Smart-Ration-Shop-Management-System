package com.RationShop.dao;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;

public class DatabaseInitializer {

    public static void initialize() {
        String createBeneficiaryTable = """
                CREATE TABLE IF NOT EXISTS beneficiaries (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    ration_card_number TEXT UNIQUE NOT NULL,
                    address TEXT,
                    phone_number TEXT,
                    family_size INTEGER
                );
                """;

        String createStockTable = """
                CREATE TABLE IF NOT EXISTS stock (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    item_name TEXT NOT NULL,
                    quantity_kg REAL,
                    last_updated TEXT
                );
                """;

        String createDistributionTable = """
                CREATE TABLE IF NOT EXISTS distributions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    beneficiary_id INTEGER,
                    distribution_date TEXT,
                    month_year TEXT,
                    items_given TEXT,
                    FOREIGN KEY(beneficiary_id) REFERENCES beneficiaries(id)
                );
                """;

        // Try-with-resources — auto closes connection even if error occurs
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement()) {

            stmt.execute(createBeneficiaryTable);
            stmt.execute(createStockTable);
            stmt.execute(createDistributionTable);

            System.out.println("Database initialized successfully.");

        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }
}