package com.RationShop.dao;

import com.RationShop.model.StockItem;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class StockDAO {

    // ADD stock item
    public boolean addStockItem(StockItem item) {
        String sql = "INSERT INTO stock (item_name, quantity_kg, last_updated) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, item.getItemName());
            stmt.setDouble(2, item.getQuantityKg());
            stmt.setString(3, item.getLastUpdated());

            stmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Error adding stock: " + e.getMessage());
            return false;
        }
    }

    // GET all stock items
    public List<StockItem> getAllStock() {
        List<StockItem> list = new ArrayList<>();
        String sql = "SELECT * FROM stock";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                StockItem item = new StockItem(
                        rs.getInt("id"),
                        rs.getString("item_name"),
                        rs.getDouble("quantity_kg"),
                        rs.getString("last_updated")
                );
                list.add(item);
            }

        } catch (SQLException e) {
            System.out.println("Error fetching stock: " + e.getMessage());
        }

        return list;
    }

    // DEDUCT quantity when ration is distributed
    public boolean deductStock(String itemName, double amountKg) {
        String sql = "UPDATE stock SET quantity_kg = quantity_kg - ?, last_updated = ? WHERE item_name = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDouble(1, amountKg);
            stmt.setString(2, LocalDate.now().toString());
            stmt.setString(3, itemName);

            stmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Error deducting stock: " + e.getMessage());
            return false;
        }
    }

    // UPDATE full quantity (when new stock arrives)
    public boolean updateStock(String itemName, double newQuantityKg) {
        String sql = "UPDATE stock SET quantity_kg = ?, last_updated = ? WHERE item_name = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDouble(1, newQuantityKg);
            stmt.setString(2, LocalDate.now().toString());
            stmt.setString(3, itemName);

            stmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Error updating stock: " + e.getMessage());
            return false;
        }
    }
}