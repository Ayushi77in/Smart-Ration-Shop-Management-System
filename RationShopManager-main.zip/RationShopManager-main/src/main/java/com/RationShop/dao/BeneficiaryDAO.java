package com.RationShop.dao;

import com.RationShop.model.Beneficiary;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BeneficiaryDAO {

    // ADD a new beneficiary to database
    public boolean addBeneficiary(Beneficiary b) {
        String sql = "INSERT INTO beneficiaries (name, ration_card_number, address, phone_number, family_size) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, b.getName());
            stmt.setString(2, b.getRationCardNumber());
            stmt.setString(3, b.getAddress());
            stmt.setString(4, b.getPhoneNumber());
            stmt.setInt(5, b.getFamilySize());

            stmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Error adding beneficiary: " + e.getMessage());
            return false;
        }
    }

    // GET all beneficiaries from database
    public List<Beneficiary> getAllBeneficiaries() {
        List<Beneficiary> list = new ArrayList<>();
        String sql = "SELECT * FROM beneficiaries";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Beneficiary b = new Beneficiary(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("ration_card_number"),
                        rs.getString("address"),
                        rs.getString("phone_number"),
                        rs.getInt("family_size")
                );
                list.add(b);
            }

        } catch (SQLException e) {
            System.out.println("Error fetching beneficiaries: " + e.getMessage());
        }

        return list;
    }

    // SEARCH beneficiary by ration card number
    public Beneficiary findByRationCard(String cardNumber) {
        String sql = "SELECT * FROM beneficiaries WHERE ration_card_number = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, cardNumber);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Beneficiary(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("ration_card_number"),
                        rs.getString("address"),
                        rs.getString("phone_number"),
                        rs.getInt("family_size")
                );
            }

        } catch (SQLException e) {
            System.out.println("Error searching beneficiary: " + e.getMessage());
        }

        return null;
    }

    // DELETE beneficiary by id
    public boolean deleteBeneficiary(int id) {
        String sql = "DELETE FROM beneficiaries WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Error deleting beneficiary: " + e.getMessage());
            return false;
        }
    }
}