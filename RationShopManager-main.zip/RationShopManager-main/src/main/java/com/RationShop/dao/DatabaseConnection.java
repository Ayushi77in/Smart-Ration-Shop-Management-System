package com.RationShop.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    // Path where your SQLite file will be created on your computer
    private static final String URL = "jdbc:sqlite:rationshop.db";

    // OOP CONCEPT: Static method — belongs to the class, not any object
    // You call it as DatabaseConnection.getConnection(), never new DatabaseConnection()
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL);
    }
}