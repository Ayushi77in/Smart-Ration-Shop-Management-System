package com.RationShop.model;

public class Beneficiary {

    // OOP CONCEPT: Encapsulation — fields are private, only accessible via methods
    private int id;
    private String name;
    private String rationCardNumber;
    private String address;
    private String phoneNumber;
    private int familySize;

    // Constructor — used to create a new Beneficiary object
    public Beneficiary(int id, String name, String rationCardNumber,
                       String address, String phoneNumber, int familySize) {
        this.id = id;
        this.name = name;
        this.rationCardNumber = rationCardNumber;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.familySize = familySize;
    }

    // Getters — the only way to READ private data from outside
    public int getId() { return id; }
    public String getName() { return name; }
    public String getRationCardNumber() { return rationCardNumber; }
    public String getAddress() { return address; }
    public String getPhoneNumber() { return phoneNumber; }
    public int getFamilySize() { return familySize; }

    // Setters — the only way to MODIFY private data from outside
    public void setName(String name) { this.name = name; }
    public void setAddress(String address) { this.address = address; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }
    public void setFamilySize(int familySize) { this.familySize = familySize; }

    // toString — useful for printing/debugging
    @Override
    public String toString() {
        return "Beneficiary{id=" + id + ", name='" + name +
                "', cardNo='" + rationCardNumber + "', family=" + familySize + "}";
    }
}