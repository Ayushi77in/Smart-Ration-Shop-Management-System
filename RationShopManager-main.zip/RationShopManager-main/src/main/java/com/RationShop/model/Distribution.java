package com.RationShop.model;

public class Distribution {

    private int id;
    private int beneficiaryId;
    private String beneficiaryName;  // for display purposes
    private String distributionDate;
    private String monthYear;        // e.g. "April-2026"
    private String itemsGiven;       // e.g. "Rice:5kg, Wheat:3kg, Sugar:1kg"

    public Distribution(int id, int beneficiaryId, String beneficiaryName,
                        String distributionDate, String monthYear, String itemsGiven) {
        this.id = id;
        this.beneficiaryId = beneficiaryId;
        this.beneficiaryName = beneficiaryName;
        this.distributionDate = distributionDate;
        this.monthYear = monthYear;
        this.itemsGiven = itemsGiven;
    }

    public int getId() { return id; }
    public int getBeneficiaryId() { return beneficiaryId; }
    public String getBeneficiaryName() { return beneficiaryName; }
    public String getDistributionDate() { return distributionDate; }
    public String getMonthYear() { return monthYear; }
    public String getItemsGiven() { return itemsGiven; }

    public void setItemsGiven(String itemsGiven) { this.itemsGiven = itemsGiven; }

    @Override
    public String toString() {
        return "Distribution{beneficiary='" + beneficiaryName +
                "', month='" + monthYear + "', items='" + itemsGiven + "'}";
    }
}