package com.RationShop.model;

public class StockItem {

    private int id;
    private String itemName;
    private double quantityKg;
    private String lastUpdated;

    public StockItem(int id, String itemName, double quantityKg, String lastUpdated) {
        this.id = id;
        this.itemName = itemName;
        this.quantityKg = quantityKg;
        this.lastUpdated = lastUpdated;
    }

    public int getId() { return id; }
    public String getItemName() { return itemName; }
    public double getQuantityKg() { return quantityKg; }
    public String getLastUpdated() { return lastUpdated; }

    public void setQuantityKg(double quantityKg) { this.quantityKg = quantityKg; }
    public void setLastUpdated(String lastUpdated) { this.lastUpdated = lastUpdated; }

    @Override
    public String toString() {
        return "StockItem{id=" + id + ", item='" + itemName +
                "', quantity=" + quantityKg + "kg, updated='" + lastUpdated + "'}";
    }
}