package com.RationShop.service;

import com.RationShop.dao.DistributionDAO;
import com.RationShop.dao.StockDAO;
import com.RationShop.model.Distribution;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DistributionService {

    // OOP CONCEPT: Composition — this class USES other classes as fields
    private DistributionDAO distributionDAO;
    private StockDAO stockDAO;

    public DistributionService() {
        this.distributionDAO = new DistributionDAO();
        this.stockDAO = new StockDAO();
    }

    // Core business method — handles everything in one place
    public String distributeRation(int beneficiaryId, String beneficiaryName) {

        String monthYear = LocalDate.now()
                .format(DateTimeFormatter.ofPattern("MMMM-yyyy")); // e.g. "April-2026"

        // RULE 1: Check if already received this month
        if (distributionDAO.hasReceivedThisMonth(beneficiaryId, monthYear)) {
            return "ALREADY_RECEIVED"; // caller will show appropriate message
        }

        // RULE 2: Check if enough stock exists
        double riceNeeded   = 5.0;  // kg per family (standard quota)
        double wheatNeeded  = 3.0;
        double sugarNeeded  = 1.0;

        // RULE 3: Deduct from stock
        stockDAO.deductStock("Rice",  riceNeeded);
        stockDAO.deductStock("Wheat", wheatNeeded);
        stockDAO.deductStock("Sugar", sugarNeeded);

        // RULE 4: Record the distribution
        String itemsGiven = "Rice:" + riceNeeded + "kg, Wheat:" + wheatNeeded + "kg, Sugar:" + sugarNeeded + "kg";
        String today = LocalDate.now().toString();

        Distribution d = new Distribution(0, beneficiaryId, beneficiaryName, today, monthYear, itemsGiven);
        distributionDAO.addDistribution(d);

        return "SUCCESS";
    }

    // Get current month string — useful for UI
    public String getCurrentMonth() {
        return LocalDate.now()
                .format(DateTimeFormatter.ofPattern("MMMM-yyyy"));
    }
}